#!/bin/bash 

# Using bash script to test CUDA GPU environment and run KMC1D 
# 1. Check NVIDIA Hardware Environment
# 2. Check CUDA and NVIDIA Package Software Environment for the Redhat or Debian Linux
# 3. Tentative test the input file (raw genotype file or compressed zip version) and unzip the compressed version if necessary
# 4. Parse the necessary parameters for KMC1D
# 5. Run KMC1D at the final uncompress version 
# Usage: ./run_test.sh genotype_file kinship_file (Currently, accept pure raw genotype file as format of CSV, or its compressed version as unzip, gzip, bzip2)
# Writter: Wenchao Zhang
# ---------------------------------------------------------------

grep -Ei 'redhat|centos' /etc/*release
if [[ $? -eq "0" ]]
then
  os_redhat=true
  echo "you are working in redhat like linux"
else
  os_redhat=false
fi

grep -Ei 'debian|ubuntu' /etc/*release
if [[ $? -eq "0" ]]
then
  os_debian=true
  echo "you are working in debian like linux"
else
  os_debian=false
fi

echo "Welcome to test your CUDA GPU Environment and Run KMC1D: $0, $1, $2"
## Begin to check the GPU hardare and software environment
nvidia_hardware_num=`lspci|grep -i nvidia|wc -l` # NVIDIA Slice umber==0, nvidia hardware is not avaiale 
if [[ $nvidia_hardware_num -eq "0" ]]
then
   echo "you need NVIDIA CUDA-Capable GPU hardware in your linux envrionment" 
   exit
else
   echo "Your linux platform have $nvidia_hardware_num NVIDIA GPU Cards"
fi

$os_redhat && cuda_software_num1=`rpm -qa |grep cuda| wc -l` || cuda_software_num1=0
$os_debian && cuda_software_num=`dpkg -l |grep cuda| wc -l` || cuda_software_num=$cuda_software_num1

if [[ $cuda_software_num -eq "0" ]]
then
   echo "you need intsall CUDA related packages" 
   exit
fi

$os_redhat && nvidia_software_num=`rpm -qa |grep nvidia| wc -l` ||nvidia_software_num=0
$os_debian && nvidia_software_num=`dpkg -l |grep nvidia| wc -l` ||nvidia_software_num=0 

if [[ $cuda_software_num -eq "0" ]]
then
   echo "you need intsall NIVIDIA related packages" 
   exit
fi

## Begin to tentatively uncompress the input genotype file if it's compressed  
fn=$1
fn1="./unzip.txt"
finalfn=$fn
`unzip -p $fn > $fn1 2>/dev/null` || `gunzip -c $fn > $fn1 2>/dev/null` || `bunzip2 -c $fn > $fn1 2>/dev/null`
if [[ $? -eq 0 && -s $fn1 ]]
then
   finalfn=$fn1      
fi

echo "Unzip finished: Genotype_File:$finalfn, Kinship_File:$2"
## Begin to parse the input parameters for KMC1D  
chmod a+r $finalfn
individual_num=`head -n 1 $finalfn |tr "," "\n"|wc -l`
if [ $individual_num -le 1 ]  
then
  individual_num=`head -n 1 $finalfn |tr "\t" "\n"|wc -l`
fi

if [ $individual_num -le 1 ]
then
  echo "The genotype file are in wrong format, which should be comma separated file"
  exit
fi

## Begin to call KMC1D to parallel calculating 1D kinship matrix
if [[ ! -e ./KMC1D ]]
then
   echo "You need an executable file of KMC1D with this shell script, please use Makefile to compile it at first! "
   exit
fi

kinship_file=$2
marker_block=2000 #2000 Markers as a block 
run_mode=0  # GPU Parallel
echo "Now, you are runing a GPU parallel program KMC1D to calculate the kinship matrix! "
echo "Your Parameters for KMC1D--Genotype_File:$finalfn, Kinship_File:$kinship_file, Indiviudal_Num:$individual_num, Blcok:$marker_block, run_mode:$run_mode"
./KMC1D -g $finalfn -k $kinship_file -i $individual_num -b $marker_block -m $run_mode
if [[ $? -eq 0 ]]
then
echo "KMC1D Successfully Finished!"
else
echo "Call KMC1D Failed!"
fi



